#include <iostream>
#include <vector>
#include <ostream>
#include <utility>
#include <algorithm>
#include <limits>
#include <cmath>

using namespace std;

using Point = pair<int, int>; //saves me from typing pair<int, int> everywhere
using Grid = vector<vector<int>>; //saves me from typing vector<vector<int>> everywhere

void print(const Grid& grid){	
	for (int y = 0; y < grid[0].size(); ++y) {
        for (int x = 0; x < grid.size(); ++x) {
            cout << grid[x][y] << ' ';
        }
        cout << endl;
    }	
}

Point readPoint(){
	int x, y;
	cin >> x >> y;
	return make_pair(x, y);
}

void set(Grid& grid, const Point& point, int value){
	grid[point.first][point.second] = value; 
}

double distSq(const Point &point, const Point &other) {
	double dx = point.first - other.first;
	double dy = point.second - other.second;
	return dx * dx + dy * dy;
}

bool isValid(const Grid& grid, const Point &point) {
	int x = point.first;
	int y = point.second;
	int width = grid.size();
	int height = grid[0].size();
	return x >= 0 && x < width && y >= 0 && y < height;
}

int at(const Grid& grid, const Point &point) {
	return grid[point.first][point.second];
}

vector<string> getMove(const Grid& grid, const Point& head, const Point &apple) {

    vector<string> best;
    double min = numeric_limits<double>::infinity(); //infinity

    for (int dx :{-1, 1}) {
        Point next(head.first + dx, head.second);
        if (isValid(grid, next) && at(grid, next) % 5 == 0) {
            double dist = distSq(next, apple);
            if (dist <= min) {
                if (dist < min) {
                    best.clear();
                    min = dist;
                }
                best.push_back(dx == -1 ? "LEFT" : "RIGHT");
            }
        }
    }
    for (int dy :{-1, 1}) {
        Point next(head.first, head.second + dy);
        if (isValid(grid, next) && at(grid, next) % 5 == 0) {
            double dist = distSq(next, apple);
            if (dist <= min) {
                if (dist < min) {
                    best.clear();
                    min = dist;
                }
                best.push_back(dy == -1 ? "UP" : "DOWN");
            }
        }
    }
	sort(best.begin(), best.end());
    return best;
}

void drawLine(Grid& grid, const Point& start, const Point& end, int val) {
    for (int x = min(start.first, end.first); x <= max(start.first, end.first); ++x) {
        for (int y = min(start.second, end.second); y <= max(start.second, end.second); ++y) {
            grid[x][y] = val;
        }
    }
}

int main() {
    int W, H;
    cin >> W >> H;
	vector<vector<int>> grid(W, vector<int>(H));
	
	Point apple = readPoint();
	set(grid, apple, 5);
	int nSnakes;
	cin >> nSnakes;
	
    for (int j = 0; j < nSnakes; ++j) {
        int k;
        cin >> k;
        Point point = readPoint();
        for (int i = 1; i < k; ++i) {
            Point point2 = readPoint();
            drawLine(grid, point, point2, j + 1);
            point = point2;
        }
    }
    print(grid);
    return 0;
}

