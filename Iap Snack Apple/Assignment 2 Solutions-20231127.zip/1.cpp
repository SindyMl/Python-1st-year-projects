#include <iostream>
#include <vector>
#include <ostream>

using namespace std;

void print(const vector<vector<int>>& grid){	
	for (int y = 0; y < grid[0].size(); ++y) {
        for (int x = 0; x < grid.size(); ++x) {
            cout << grid[x][y] << ' ';
        }
        cout << endl;
    }	
}

int main() {
    int W, H;
    cin >> W >> H;
	vector<vector<int>> grid(W, vector<int>(H));
	
	print(grid);
   
    return 0;
}

