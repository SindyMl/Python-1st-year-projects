#include <iostream>
#include <vector>
#include <ostream>
#include <utility>

using namespace std;

using Point = pair<int, int>;  //too lazy to keep writing pair, so just define a new, easy to write type

void print(const vector<vector<int>>& grid){	
	for (int y = 0; y < grid[0].size(); ++y) {
        for (int x = 0; x < grid.size(); ++x) {
            cout << grid[x][y] << ' ';
        }
        cout << endl;
    }	
}

Point readPoint(){
	int x, y;
	cin >> x >> y;
	return make_pair(x, y);
}

void set(vector<vector<int>>& grid, const Point& point, int value){
	grid[point.first][point.second] = value; 
}

int main() {
    int W, H;
    cin >> W >> H;
	vector<vector<int>> grid(W, vector<int>(H));
	
	Point apple = readPoint();
	set(grid, apple, 5);
	
	int nSnakes;
	cin >> nSnakes;
	for (int k = 0; k < nSnakes; ++k){ 
		for (int i = 0; i < 3; ++i) {
			Point snake = readPoint();
			set(grid, snake, k+1);
		}
	}
	
	print(grid);
   
    return 0;
}

