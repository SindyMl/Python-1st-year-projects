#include <iostream>
#include <vector>
#include <ostream>
#include <utility>

using namespace std;

void print(const vector<vector<int>>& grid){	
	for (int y = 0; y < grid[0].size(); ++y) {
        for (int x = 0; x < grid.size(); ++x) {
            cout << grid[x][y] << ' ';
        }
        cout << endl;
    }	
}

pair<int, int> readPoint(){
	int x, y;
	cin >> x >> y;
	return make_pair(x, y);
}

void set(vector<vector<int>>& grid, const pair<int, int>& point, int value){
	grid[point.first][point.second] = value; 
}

int main() {
    int W, H;
    cin >> W >> H;
	vector<vector<int>> grid(W, vector<int>(H));
	
	pair<int, int> apple = readPoint();
	set(grid, apple, 5);
    for (int i = 0; i < 3; ++i) {
		pair<int, int> snake = readPoint();
		set(grid, snake, 1);
    }
	
	print(grid);
   
    return 0;
}

