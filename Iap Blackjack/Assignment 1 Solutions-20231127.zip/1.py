

card = input()
if len(card) == 3 or card[0] >= 'J':
    print(10)
elif card[0] == 'A':
    print('1 or 11')
else:
    print(card[0])