PLAYER_WIN = 1
DEALER_WIN = -1
PUSH = 0


def get_low_score(card):
    if len(card) == 3 or card[0] >= 'J':
        return 10
    elif card[0] == 'A':
        return 1
    return int(card[0])


def get_hand_score(hand):
    soft = False
    score = 0
    for card in hand:
        if card[0] == 'A':
            soft = True
        score += get_low_score(card)
    if score > 11 and soft:
        soft = False  # no longer an option, since it would be a bust
    return score, soft


def get_winner(player_hand, dealer_hand):
    player_score, soft = get_hand_score(player_hand)
    if player_score == 11 and len(player_hand) == 2 and soft:
        return PLAYER_WIN  # player has blackjack. condition 1
    elif player_score > 21:
        return DEALER_WIN  # player is bust. condition 2

    if soft:
        player_score += 10  # get higher score

    dealer_score, soft = get_hand_score(dealer_hand)
    if dealer_score == 11 and len(dealer_hand) == 2 and soft:
        return DEALER_WIN  # dealer has blackjack. condition 3
    elif dealer_score > 21:
        return PLAYER_WIN  # dealer is bust. condition 4

    if soft:
        dealer_score += 10  # get higher score

    # condition 5
    if player_score == dealer_score:
        return PUSH
    elif player_score > dealer_score:
        return PLAYER_WIN
    else:
        return DEALER_WIN


def get_cards():
    cards = list()
    card = input()
    while card != 'end':
        cards.append(card)
        card = input()
    return cards


player_cards = get_cards()
dealer_cards = get_cards()

outcome = get_winner(player_cards, dealer_cards)
if outcome == PLAYER_WIN:
    print('Player wins!')
elif outcome == DEALER_WIN:
    print('Dealer wins!')
else:
    print('Push!')
