def get_low_score(card):
    if len(card) == 3 or card[0] >= 'J':
        return 10
    elif card[0] == 'A':
        return 1
    return int(card[0])

def get_hand_score(hand):
    soft = False
    score = 0
    for card in hand:
        if card[0] == 'A':
            soft = True
        score += get_low_score(card)
    if score > 11 and soft:
        soft = False  # no longer an option, since it would be a bust
    return score, soft


cards = list()
card = input()
while card != 'end':
    cards.append(card)
    card = input()

score, soft = get_hand_score(cards)
if score > 21:
    print('Bust!')
elif score == 11 and soft and len(cards) == 2:
    print('Blackjack!')
elif soft:
    print(score, 'or', score + 10)
else:
    print(score)