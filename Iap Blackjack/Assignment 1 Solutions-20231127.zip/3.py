def score_card(card, low=True):
    if len(card) == 3 or card[0] >= 'J':
        return 10
    elif card[0] == 'A':
        if low:
            return 1
        return 11
    return int(card[0])

def score_hand(hand):
    soft = False
    score = 0
    for card in hand:
        if card[0] == 'A':
            soft = True
        score += score_card(card)
    return score, soft

def should_hit(player_score, dealer_score, usable_ace):
    if usable_ace:
        if player_score <= 7:
            return True
        elif player_score == 8 and (dealer_score >= 9 or dealer_score == 1):
            return True
    else:
        if player_score <= 11:
            return True
        elif player_score >= 17:
            return False
        elif player_score == 12:
            return dealer_score < 4 or dealer_score > 6
        elif dealer_score >= 7 or dealer_score == 1:
            return True
    return False


dealer = input()
card1 = input()
card2 = input()

player_score, soft = score_hand([card1, card2])
dealer_score, _ = score_hand([dealer])

if should_hit(player_score, dealer_score, soft):
    print('Hit')
else:
    print('Stand')
