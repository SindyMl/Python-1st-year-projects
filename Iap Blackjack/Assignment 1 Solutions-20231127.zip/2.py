def score_card(card, low=True):
    if len(card) == 3 or card[0] >= 'J':
        return 10
    elif card[0] == 'A':
        if low:
            return 1
        return 11
    return int(card[0])
	

card1 = input()
card2 = input()
soft = False
if card1[0] == 'A' or card2[0] == 'A':
	soft = True
score = score_card(card1) + score_card(card2)
if soft:
	if score == 11:
		print('Blackjack!')
	else:
		print(score, 'or', score + 10)
else:
	print(score)